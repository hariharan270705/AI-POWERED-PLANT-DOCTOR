import streamlit as st
import pandas as pd
import os
from utils.data_handler import DataHandler
from utils.database import DatabaseManager

# Configure page
st.set_page_config(
    page_title="Smart Plant Doctor",
    page_icon="🌱",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better mobile responsiveness
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 1rem 0;
        border-bottom: 2px solid #2E8B57;
        margin-bottom: 2rem;
    }
    .feature-card {
        padding: 1rem;
        border-radius: 10px;
        border: 1px solid #e0e0e0;
        margin: 1rem 0;
        background-color: #f8f9fa;
        height: 180px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .feature-card h3 {
        margin-top: 0;
        color: #2E8B57;
    }
    .stButton > button {
        width: 100%;
        margin-top: 10px;
    }
    @media (max-width: 768px) {
        .feature-card {
            height: auto;
            margin: 0.5rem 0;
        }
    }
    .upload-section {
        border: 2px dashed #2E8B57;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🌱 Smart Plant Doctor</h1>
        <p>Your AI-powered assistant for plant disease detection and management</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize session state and database
    if 'data_handler' not in st.session_state:
        st.session_state.data_handler = None
    if 'db_manager' not in st.session_state:
        st.session_state.db_manager = DatabaseManager()
    
    # File upload section
    st.markdown("""
    <div class="upload-section">
        <h2>📁 Upload Your Plant Disease Dataset</h2>
        <p>Upload the Plant_Disease_Solutions_100_Crops.csv file to get started</p>
    </div>
    """, unsafe_allow_html=True)
    
    uploaded_file = st.file_uploader(
        "Choose CSV file",
        type=['csv'],
        help="Upload the Plant_Disease_Solutions_100_Crops.csv file or any compatible CSV with the required columns"
    )
    
    if uploaded_file is not None:
        try:
            with st.spinner("Loading dataset..."):
                # Initialize data handler
                st.session_state.data_handler = DataHandler(uploaded_file)
                df = st.session_state.data_handler.get_data()
                
                # Save data to database
                if st.session_state.db_manager.load_csv_to_database(df):
                    st.success("📊 Data saved to database successfully!")
                
            st.success(f"✅ Dataset loaded successfully! Found {len(df)} records covering {df['Crop Name'].nunique()} crops.")
            
            # Show dataset preview
            with st.expander("📋 Dataset Preview"):
                st.dataframe(df.head(10), use_container_width=True)
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total Records", len(df))
                with col2:
                    st.metric("Unique Crops", int(df['Crop Name'].nunique()))
                with col3:
                    st.metric("Unique Diseases", int(df['Disease Name'].nunique()))
            
            # Navigation guidance
            st.header("🚀 Get Started")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.markdown("""
                <div class="feature-card">
                    <h3>🔍 Search & Browse</h3>
                    <p>Search for specific crops or diseases and get detailed information about symptoms, causes, and solutions.</p>
                </div>
                """, unsafe_allow_html=True)
                if st.button("Go to Search", key="search_btn"):
                    st.switch_page("pages/1_🔍_Search.py")
            
            with col2:
                st.markdown("""
                <div class="feature-card">
                    <h3>💬 AI Chatbot</h3>
                    <p>Ask natural language questions about plant diseases and get AI-powered answers based on your dataset.</p>
                </div>
                """, unsafe_allow_html=True)
                if st.button("Go to Chatbot", key="chat_btn"):
                    st.switch_page("pages/2_💬_Chatbot.py")
            
            with col3:
                st.markdown("""
                <div class="feature-card">
                    <h3>📸 Image Detection</h3>
                    <p>Upload plant leaf images to detect diseases using AI-powered image analysis and get instant treatment recommendations.</p>
                </div>
                """, unsafe_allow_html=True)
                if st.button("Go to Image Detection", key="image_btn"):
                    st.switch_page("pages/4_📸_Image_Detection.py")
            
            with col4:
                st.markdown("""
                <div class="feature-card">
                    <h3>📊 Analytics</h3>
                    <p>Explore data visualizations showing disease patterns, crop statistics, and trends in your dataset.</p>
                </div>
                """, unsafe_allow_html=True)
                if st.button("Go to Analytics", key="analytics_btn"):
                    st.switch_page("pages/3_📊_Analytics.py")
                    
        except Exception as e:
            st.error(f"❌ Error loading dataset: {str(e)}")
            st.info("Please ensure you're uploading a valid CSV file with the expected columns.")
    
    else:
        st.info("👆 Please upload your Plant Disease Solutions CSV file to get started.")
        
        # Show expected format
        with st.expander("📋 Expected CSV Format"):
            st.markdown("""
            Your CSV file should contain the following columns:
            - **Crop Name**: Name of the crop (e.g., Tomato, Potato)
            - **Disease Name**: Name of the disease (e.g., Late Blight, Leaf Curl)
            - **Symptoms**: Description of disease symptoms
            - **Cause**: What causes the disease
            - **Organic Solution**: Natural/organic treatment methods
            - **Chemical Solution**: Chemical treatment options
            - **Prevention Tips**: How to prevent the disease
            """)

if __name__ == "__main__":
    main()
