import os
import pandas as pd
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime
from typing import List, Dict, Optional
import streamlit as st

# Database configuration
DATABASE_URL = os.environ.get('DATABASE_URL')
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Database Models
class PlantDisease(Base):
    __tablename__ = "plant_diseases"
    
    id = Column(Integer, primary_key=True, index=True)
    crop_name = Column(String(100), nullable=False, index=True)
    disease_name = Column(String(200), nullable=False, index=True)
    symptoms = Column(Text, nullable=True)
    cause = Column(Text, nullable=True)
    organic_solution = Column(Text, nullable=True)
    chemical_solution = Column(Text, nullable=True)
    prevention_tips = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class UserQuery(Base):
    __tablename__ = "user_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    query_text = Column(Text, nullable=False)
    query_type = Column(String(50), nullable=False)  # 'search', 'chatbot', 'image'
    response_text = Column(Text, nullable=True)
    session_id = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ImageAnalysis(Base):
    __tablename__ = "image_analyses"
    
    id = Column(Integer, primary_key=True, index=True)
    image_name = Column(String(200), nullable=True)
    predicted_disease = Column(String(200), nullable=True)
    confidence_score = Column(Float, nullable=True)
    crop_type = Column(String(100), nullable=True)
    analysis_result = Column(Text, nullable=True)  # JSON string of full results
    user_feedback = Column(String(20), nullable=True)  # 'correct', 'incorrect', 'partial'
    session_id = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class DatabaseManager:
    def __init__(self):
        self.engine = engine
        self.SessionLocal = SessionLocal
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize database tables."""
        try:
            Base.metadata.create_all(bind=self.engine)
            st.success("Database connection established successfully!")
        except Exception as e:
            st.error(f"Database initialization failed: {str(e)}")
    
    def get_session(self) -> Session:
        """Get database session."""
        return self.SessionLocal()
    
    def load_csv_to_database(self, csv_data: pd.DataFrame) -> bool:
        """Load CSV data into the database."""
        try:
            session = self.get_session()
            
            # Clear existing data
            session.query(PlantDisease).delete()
            
            # Insert new data
            for _, row in csv_data.iterrows():
                disease = PlantDisease(
                    crop_name=str(row.get('Crop Name', '')),
                    disease_name=str(row.get('Disease Name', '')),
                    symptoms=str(row.get('Symptoms', '')),
                    cause=str(row.get('Cause', '')),
                    organic_solution=str(row.get('Organic Solution', '')),
                    chemical_solution=str(row.get('Chemical Solution', '')),
                    prevention_tips=str(row.get('Prevention Tips', ''))
                )
                session.add(disease)
            
            session.commit()
            session.close()
            return True
            
        except Exception as e:
            st.error(f"Error loading data to database: {str(e)}")
            session.rollback()
            session.close()
            return False
    
    def search_diseases(self, query: str, search_type: str = 'all') -> List[Dict]:
        """Search diseases in the database."""
        try:
            session = self.get_session()
            
            if search_type == 'crop':
                results = session.query(PlantDisease).filter(
                    PlantDisease.crop_name.ilike(f'%{query}%')
                ).all()
            elif search_type == 'disease':
                results = session.query(PlantDisease).filter(
                    PlantDisease.disease_name.ilike(f'%{query}%')
                ).all()
            elif search_type == 'symptoms':
                results = session.query(PlantDisease).filter(
                    PlantDisease.symptoms.ilike(f'%{query}%')
                ).all()
            else:
                # Search all fields
                results = session.query(PlantDisease).filter(
                    (PlantDisease.crop_name.ilike(f'%{query}%')) |
                    (PlantDisease.disease_name.ilike(f'%{query}%')) |
                    (PlantDisease.symptoms.ilike(f'%{query}%'))
                ).all()
            
            # Convert to dictionary
            disease_list = []
            for result in results:
                disease_list.append({
                    'id': result.id,
                    'Crop Name': result.crop_name,
                    'Disease Name': result.disease_name,
                    'Symptoms': result.symptoms,
                    'Cause': result.cause,
                    'Organic Solution': result.organic_solution,
                    'Chemical Solution': result.chemical_solution,
                    'Prevention Tips': result.prevention_tips
                })
            
            session.close()
            return disease_list
            
        except Exception as e:
            st.error(f"Database search error: {str(e)}")
            return []
    
    def get_all_diseases(self) -> List[Dict]:
        """Get all diseases from database."""
        try:
            session = self.get_session()
            results = session.query(PlantDisease).all()
            
            disease_list = []
            for result in results:
                disease_list.append({
                    'id': result.id,
                    'Crop Name': result.crop_name,
                    'Disease Name': result.disease_name,
                    'Symptoms': result.symptoms,
                    'Cause': result.cause,
                    'Organic Solution': result.organic_solution,
                    'Chemical Solution': result.chemical_solution,
                    'Prevention Tips': result.prevention_tips
                })
            
            session.close()
            return disease_list
            
        except Exception as e:
            st.error(f"Error fetching diseases: {str(e)}")
            return []
    
    def log_user_query(self, query_text: str, query_type: str, response_text: str = None, session_id: str = None):
        """Log user query to database."""
        try:
            session = self.get_session()
            
            user_query = UserQuery(
                query_text=query_text,
                query_type=query_type,
                response_text=response_text,
                session_id=session_id
            )
            
            session.add(user_query)
            session.commit()
            session.close()
            
        except Exception as e:
            st.warning(f"Query logging failed: {str(e)}")
    
    def log_image_analysis(self, image_name: str, predicted_disease: str, confidence_score: float, 
                          crop_type: str, analysis_result: str, session_id: str = None):
        """Log image analysis to database."""
        try:
            session = self.get_session()
            
            analysis = ImageAnalysis(
                image_name=image_name,
                predicted_disease=predicted_disease,
                confidence_score=confidence_score,
                crop_type=crop_type,
                analysis_result=analysis_result,
                session_id=session_id
            )
            
            session.add(analysis)
            session.commit()
            session.close()
            
        except Exception as e:
            st.warning(f"Image analysis logging failed: {str(e)}")
    
    def get_analytics_data(self) -> Dict:
        """Get analytics data from database."""
        try:
            session = self.get_session()
            
            # Query counts
            total_diseases = session.query(PlantDisease).count()
            total_queries = session.query(UserQuery).count()
            total_image_analyses = session.query(ImageAnalysis).count()
            
            # Top searched crops
            crop_counts = session.query(PlantDisease.crop_name, session.query(PlantDisease).filter(
                PlantDisease.crop_name == PlantDisease.crop_name
            ).count().label('count')).group_by(PlantDisease.crop_name).all()
            
            # Recent activity
            recent_queries = session.query(UserQuery).order_by(UserQuery.created_at.desc()).limit(10).all()
            
            session.close()
            
            return {
                'total_diseases': total_diseases,
                'total_queries': total_queries,
                'total_image_analyses': total_image_analyses,
                'crop_counts': crop_counts,
                'recent_queries': recent_queries
            }
            
        except Exception as e:
            st.error(f"Analytics data fetch failed: {str(e)}")
            return {}
    
    def get_unique_crops(self) -> List[str]:
        """Get list of unique crop names."""
        try:
            session = self.get_session()
            crops = session.query(PlantDisease.crop_name).distinct().all()
            session.close()
            return [crop[0] for crop in crops if crop[0]]
        except Exception as e:
            st.error(f"Error fetching crops: {str(e)}")
            return []
    
    def get_diseases_by_crop(self, crop_name: str) -> List[str]:
        """Get diseases for a specific crop."""
        try:
            session = self.get_session()
            diseases = session.query(PlantDisease.disease_name).filter(
                PlantDisease.crop_name.ilike(f'%{crop_name}%')
            ).distinct().all()
            session.close()
            return [disease[0] for disease in diseases if disease[0]]
        except Exception as e:
            st.error(f"Error fetching diseases for crop: {str(e)}")
            return []