import pandas as pd
import io
import base64
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from datetime import datetime
import streamlit as st

class ExportUtils:
    @staticmethod
    def export_to_csv(data: pd.DataFrame, filename: str = "plant_disease_data.csv") -> str:
        """Export DataFrame to CSV and return download link."""
        csv_buffer = io.StringIO()
        data.to_csv(csv_buffer, index=False)
        csv_string = csv_buffer.getvalue()
        
        # Create download link
        b64 = base64.b64encode(csv_string.encode()).decode()
        href = f'<a href="data:file/csv;base64,{b64}" download="{filename}">Download CSV</a>'
        return href
    
    @staticmethod
    def create_pdf_report(data: pd.DataFrame, title: str = "Plant Disease Report", 
                         query: str = "", response: str = "") -> bytes:
        """Create a PDF report from the data."""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=0.5*inch)
        
        # Styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Title'],
            fontSize=16,
            spaceAfter=20,
            textColor=colors.darkgreen
        )
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=12,
            spaceAfter=10,
            textColor=colors.darkblue
        )
        
        content = []
        
        # Title
        content.append(Paragraph(title, title_style))
        content.append(Spacer(1, 12))
        
        # Report metadata
        content.append(Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
        if query:
            content.append(Paragraph(f"Query: {query}", styles['Normal']))
        content.append(Spacer(1, 12))
        
        # AI Response (if provided)
        if response:
            content.append(Paragraph("AI Assistant Response:", heading_style))
            content.append(Paragraph(response, styles['Normal']))
            content.append(Spacer(1, 12))
        
        # Data section
        if not data.empty:
            content.append(Paragraph("Detailed Information:", heading_style))
            
            for idx, row in data.iterrows():
                content.append(Paragraph(f"Record {idx + 1}:", styles['Heading3']))
                
                # Create a table for each record
                record_data = [
                    ['Field', 'Information'],
                    ['Crop Name', str(row.get('Crop Name', 'N/A'))],
                    ['Disease Name', str(row.get('Disease Name', 'N/A'))],
                    ['Symptoms', str(row.get('Symptoms', 'N/A'))[:200] + ('...' if len(str(row.get('Symptoms', ''))) > 200 else '')],
                    ['Cause', str(row.get('Cause', 'N/A'))[:200] + ('...' if len(str(row.get('Cause', ''))) > 200 else '')],
                    ['Organic Solution', str(row.get('Organic Solution', 'N/A'))[:200] + ('...' if len(str(row.get('Organic Solution', ''))) > 200 else '')],
                    ['Chemical Solution', str(row.get('Chemical Solution', 'N/A'))[:200] + ('...' if len(str(row.get('Chemical Solution', ''))) > 200 else '')],
                    ['Prevention Tips', str(row.get('Prevention Tips', 'N/A'))[:200] + ('...' if len(str(row.get('Prevention Tips', ''))) > 200 else '')]
                ]
                
                table = Table(record_data, colWidths=[2*inch, 4*inch])
                table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                ]))
                
                content.append(table)
                content.append(Spacer(1, 12))
        else:
            content.append(Paragraph("No data available for the specified query.", styles['Normal']))
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.getvalue()
    
    @staticmethod
    def download_csv_button(data: pd.DataFrame, filename: str, button_text: str = "Download CSV"):
        """Create a Streamlit download button for CSV."""
        csv_buffer = io.StringIO()
        data.to_csv(csv_buffer, index=False)
        
        return st.download_button(
            label=button_text,
            data=csv_buffer.getvalue(),
            file_name=filename,
            mime="text/csv"
        )
    
    @staticmethod
    def download_pdf_button(data: pd.DataFrame, title: str, filename: str, 
                           button_text: str = "Download PDF", query: str = "", response: str = ""):
        """Create a Streamlit download button for PDF."""
        pdf_bytes = ExportUtils.create_pdf_report(data, title, query, response)
        
        return st.download_button(
            label=button_text,
            data=pdf_bytes,
            file_name=filename,
            mime="application/pdf"
        )
    
    @staticmethod
    def create_summary_export(data_handler) -> pd.DataFrame:
        """Create a summary DataFrame for export."""
        if data_handler is None:
            return pd.DataFrame()
        
        df = data_handler.get_data()
        if df.empty:
            return pd.DataFrame()
        
        # Create summary statistics
        summary_data = []
        
        # Overall statistics
        summary_data.append({
            'Metric': 'Total Records',
            'Value': len(df),
            'Description': 'Total number of disease records in dataset'
        })
        
        summary_data.append({
            'Metric': 'Unique Crops',
            'Value': df['Crop Name'].nunique(),
            'Description': 'Number of different crops covered'
        })
        
        summary_data.append({
            'Metric': 'Unique Diseases',
            'Value': df['Disease Name'].nunique(),
            'Description': 'Number of different diseases documented'
        })
        
        # Top diseases
        top_disease = df['Disease Name'].value_counts().index[0]
        top_disease_count = df['Disease Name'].value_counts().iloc[0]
        summary_data.append({
            'Metric': 'Most Common Disease',
            'Value': f"{top_disease} ({top_disease_count} records)",
            'Description': 'Disease affecting the most crops'
        })
        
        # Top crop
        top_crop = df['Crop Name'].value_counts().index[0]
        top_crop_count = df['Crop Name'].value_counts().iloc[0]
        summary_data.append({
            'Metric': 'Most Documented Crop',
            'Value': f"{top_crop} ({top_crop_count} records)",
            'Description': 'Crop with the most disease records'
        })
        
        return pd.DataFrame(summary_data)
