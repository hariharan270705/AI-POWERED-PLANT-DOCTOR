import os
import json
from typing import List, Dict
from openai import OpenAI
import streamlit as st

class PlantDoctorChatbot:
    def __init__(self):
        """Initialize the chatbot with OpenAI API."""
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        if not self.api_key:
            raise ValueError("OpenAI API key not found in environment variables")
        
        self.client = OpenAI(api_key=self.api_key)
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        self.model = "gpt-4o"
    
    def create_context_prompt(self, user_query: str, relevant_data: List[Dict]) -> str:
        """Create a context-aware prompt for the chatbot."""
        context = "You are a plant disease expert assistant. Use the following plant disease data to answer the user's question:\n\n"
        
        if relevant_data:
            for i, data in enumerate(relevant_data[:3], 1):  # Limit to top 3 most relevant
                context += f"Record {i}:\n"
                context += f"- Crop: {data.get('Crop Name', 'N/A')}\n"
                context += f"- Disease: {data.get('Disease Name', 'N/A')}\n"
                context += f"- Symptoms: {data.get('Symptoms', 'N/A')}\n"
                context += f"- Cause: {data.get('Cause', 'N/A')}\n"
                context += f"- Organic Solution: {data.get('Organic Solution', 'N/A')}\n"
                context += f"- Chemical Solution: {data.get('Chemical Solution', 'N/A')}\n"
                context += f"- Prevention: {data.get('Prevention Tips', 'N/A')}\n\n"
        else:
            context += "No specific data found for this query. Please provide general guidance if possible.\n\n"
        
        context += f"User Question: {user_query}\n\n"
        context += """Please provide a helpful, accurate response based on the data above. If the data doesn't contain relevant information, say so clearly and provide general plant care advice if appropriate. Structure your response with:
1. Direct answer to the question
2. Relevant symptoms (if applicable)
3. Recommended solutions (organic and/or chemical)
4. Prevention tips
5. Additional advice if helpful

Keep the response conversational but informative."""
        
        return context
    
    def get_response(self, user_query: str, relevant_data: List[Dict] = None) -> str:
        """Get chatbot response for user query."""
        try:
            if relevant_data is None:
                relevant_data = []
            
            prompt = self.create_context_prompt(user_query, relevant_data)
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert plant pathologist and agricultural advisor. Provide accurate, helpful information about plant diseases, their symptoms, causes, and treatments. Always base your responses on the provided data when available."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=1000,
                temperature=0.7
            )
            
            return response.choices[0].message.content or "I apologize, but I couldn't generate a response. Please try rephrasing your question."
            
        except Exception as e:
            return f"I apologize, but I encountered an error while processing your request: {str(e)}. Please try rephrasing your question or check your API connection."
    
    def analyze_query_intent(self, query: str) -> Dict:
        """Analyze user query to understand intent and extract key terms."""
        try:
            analysis_prompt = f"""Analyze this plant disease query and extract key information in JSON format:
Query: "{query}"

Provide a JSON response with:
- "intent": the main purpose (search_crop, search_disease, ask_symptoms, ask_treatment, ask_prevention, general_question)
- "crop_mentioned": any crop names mentioned (list)
- "disease_mentioned": any disease names mentioned (list)
- "keywords": important terms for searching (list)
- "question_type": type of question (what, how, why, when, where)

Example: {{"intent": "ask_treatment", "crop_mentioned": ["tomato"], "disease_mentioned": ["blight"], "keywords": ["organic", "treatment"], "question_type": "how"}}"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": analysis_prompt}],
                response_format={"type": "json_object"},
                max_tokens=300
            )
            
            content = response.choices[0].message.content
            if content:
                return json.loads(content)
            else:
                return {"intent": "general_question", "crop_mentioned": [], "disease_mentioned": [], "keywords": [], "question_type": "general"}
            
        except Exception as e:
            # Fallback analysis
            query_lower = query.lower()
            intent = "general_question"
            
            if any(word in query_lower for word in ["treatment", "cure", "solution", "remedy"]):
                intent = "ask_treatment"
            elif any(word in query_lower for word in ["prevent", "prevention", "avoid"]):
                intent = "ask_prevention"
            elif any(word in query_lower for word in ["symptom", "sign", "look like", "identify"]):
                intent = "ask_symptoms"
            elif any(word in query_lower for word in ["cause", "why", "reason"]):
                intent = "ask_cause"
            
            return {
                "intent": intent,
                "crop_mentioned": [],
                "disease_mentioned": [],
                "keywords": query.split(),
                "question_type": "general"
            }
    
    def get_suggested_questions(self, crop_name: str = None, disease_name: str = None) -> List[str]:
        """Generate suggested questions based on context."""
        suggestions = [
            "What are the common diseases affecting tomatoes?",
            "How do I treat fungal infections organically?",
            "What causes leaf yellowing in plants?",
            "How can I prevent pest attacks on my crops?",
            "What are the symptoms of bacterial wilt?"
        ]
        
        if crop_name and isinstance(crop_name, str):
            suggestions.extend([
                f"What diseases commonly affect {crop_name}?",
                f"How do I keep {crop_name} plants healthy?",
                f"What are the best organic treatments for {crop_name}?"
            ])
        
        if disease_name and isinstance(disease_name, str):
            suggestions.extend([
                f"How do I treat {disease_name}?",
                f"What causes {disease_name}?",
                f"How can I prevent {disease_name}?"
            ])
        
        return suggestions[:6]  # Return top 6 suggestions
