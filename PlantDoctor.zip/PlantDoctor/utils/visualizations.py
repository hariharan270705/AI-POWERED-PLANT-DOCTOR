import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import streamlit as st
from typing import Dict, List

class PlantDataVisualizer:
    def __init__(self, data_handler):
        """Initialize visualizer with data handler."""
        self.data_handler = data_handler
        self.df = data_handler.get_data() if data_handler else pd.DataFrame()
    
    def create_disease_frequency_chart(self) -> go.Figure:
        """Create a bar chart showing most common diseases."""
        if self.df.empty:
            return self._create_empty_chart("No data available")
        
        disease_counts = self.df['Disease Name'].value_counts().head(15)
        
        fig = px.bar(
            x=disease_counts.values,
            y=disease_counts.index,
            orientation='h',
            title="Top 15 Most Common Plant Diseases",
            labels={'x': 'Number of Crops Affected', 'y': 'Disease Name'},
            color=disease_counts.values,
            color_continuous_scale='Viridis'
        )
        
        fig.update_layout(
            height=600,
            showlegend=False,
            title_font_size=16,
            xaxis_title="Number of Crops Affected",
            yaxis_title="Disease Name"
        )
        
        return fig
    
    def create_crop_diversity_chart(self) -> go.Figure:
        """Create a chart showing crops with most diseases."""
        if self.df.empty:
            return self._create_empty_chart("No data available")
        
        crop_disease_counts = self.df.groupby('Crop Name')['Disease Name'].nunique().sort_values(ascending=True).tail(15)
        
        fig = px.bar(
            x=crop_disease_counts.values,
            y=crop_disease_counts.index,
            orientation='h',
            title="Top 15 Crops by Number of Known Diseases",
            labels={'x': 'Number of Different Diseases', 'y': 'Crop Name'},
            color=crop_disease_counts.values,
            color_continuous_scale='Reds'
        )
        
        fig.update_layout(
            height=600,
            showlegend=False,
            title_font_size=16,
            xaxis_title="Number of Different Diseases",
            yaxis_title="Crop Name"
        )
        
        return fig
    
    def create_disease_distribution_pie(self) -> go.Figure:
        """Create a pie chart showing disease type distribution."""
        if self.df.empty:
            return self._create_empty_chart("No data available")
        
        # Categorize diseases by common keywords
        disease_categories = {
            'Fungal': ['rust', 'blight', 'mildew', 'rot', 'fungal', 'anthracnose', 'scab'],
            'Bacterial': ['bacterial', 'wilt', 'canker', 'spot', 'blight'],
            'Viral': ['virus', 'viral', 'mosaic', 'curl', 'yellow'],
            'Pest': ['aphid', 'thrips', 'mite', 'insect', 'caterpillar', 'borer'],
            'Nutrient': ['deficiency', 'nutrient', 'nitrogen', 'phosphorus', 'potassium']
        }
        
        category_counts = {category: 0 for category in disease_categories}
        category_counts['Other'] = 0
        
        for disease in self.df['Disease Name'].str.lower():
            categorized = False
            for category, keywords in disease_categories.items():
                if any(keyword in disease for keyword in keywords):
                    category_counts[category] += 1
                    categorized = True
                    break
            if not categorized:
                category_counts['Other'] += 1
        
        # Remove categories with 0 count
        category_counts = {k: v for k, v in category_counts.items() if v > 0}
        
        fig = px.pie(
            values=list(category_counts.values()),
            names=list(category_counts.keys()),
            title="Disease Category Distribution",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(
            height=500,
            title_font_size=16
        )
        
        return fig
    
    def create_crops_per_disease_scatter(self) -> go.Figure:
        """Create a scatter plot showing relationship between diseases and affected crops."""
        if self.df.empty:
            return self._create_empty_chart("No data available")
        
        disease_stats = self.df.groupby('Disease Name').agg({
            'Crop Name': 'nunique'
        }).reset_index()
        disease_stats.columns = ['Disease', 'Crops_Affected']
        
        # Add frequency data
        disease_frequency = self.df['Disease Name'].value_counts().reset_index()
        disease_frequency.columns = ['Disease', 'Total_Records']
        
        combined_stats = pd.merge(disease_stats, disease_frequency, on='Disease')
        
        fig = px.scatter(
            combined_stats,
            x='Crops_Affected',
            y='Total_Records',
            hover_data=['Disease'],
            title="Disease Impact: Crops Affected vs Total Records",
            labels={
                'Crops_Affected': 'Number of Different Crops Affected',
                'Total_Records': 'Total Records in Dataset'
            },
            size='Total_Records',
            color='Crops_Affected',
            color_continuous_scale='Viridis'
        )
        
        fig.update_layout(
            height=500,
            title_font_size=16
        )
        
        return fig
    
    def create_summary_metrics(self) -> Dict:
        """Create summary metrics for dashboard."""
        if self.df.empty:
            return {}
        
        stats = self.data_handler.get_disease_stats()
        
        # Calculate additional metrics
        avg_diseases_per_crop = self.df.groupby('Crop Name')['Disease Name'].nunique().mean()
        most_affected_crop = self.df.groupby('Crop Name')['Disease Name'].nunique().idxmax()
        most_common_disease = self.df['Disease Name'].value_counts().index[0]
        
        # Find crops with organic solutions
        organic_solutions = self.df[self.df['Organic Solution'].str.len() > 10]['Crop Name'].nunique()
        
        return {
            'total_records': stats['total_records'],
            'unique_crops': stats['unique_crops'],
            'unique_diseases': stats['unique_diseases'],
            'avg_diseases_per_crop': round(avg_diseases_per_crop, 1),
            'most_affected_crop': most_affected_crop,
            'most_common_disease': most_common_disease,
            'crops_with_organic_solutions': organic_solutions
        }
    
    def create_solution_type_analysis(self) -> go.Figure:
        """Analyze availability of organic vs chemical solutions."""
        if self.df.empty:
            return self._create_empty_chart("No data available")
        
        # Count records with meaningful solutions
        organic_available = len(self.df[
            (self.df['Organic Solution'].str.len() > 10) & 
            (~self.df['Organic Solution'].str.contains('not specified', case=False, na=False))
        ])
        
        chemical_available = len(self.df[
            (self.df['Chemical Solution'].str.len() > 10) & 
            (~self.df['Chemical Solution'].str.contains('not specified', case=False, na=False))
        ])
        
        both_available = len(self.df[
            (self.df['Organic Solution'].str.len() > 10) & 
            (self.df['Chemical Solution'].str.len() > 10) &
            (~self.df['Organic Solution'].str.contains('not specified', case=False, na=False)) &
            (~self.df['Chemical Solution'].str.contains('not specified', case=False, na=False))
        ])
        
        categories = ['Organic Solutions', 'Chemical Solutions', 'Both Available']
        values = [organic_available, chemical_available, both_available]
        
        fig = px.bar(
            x=categories,
            y=values,
            title="Solution Availability Analysis",
            labels={'x': 'Solution Type', 'y': 'Number of Records'},
            color=values,
            color_continuous_scale='Greens'
        )
        
        fig.update_layout(
            height=400,
            showlegend=False,
            title_font_size=16
        )
        
        return fig
    
    def _create_empty_chart(self, message: str) -> go.Figure:
        """Create an empty chart with a message."""
        fig = go.Figure()
        fig.add_annotation(
            text=message,
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.5,
            showarrow=False,
            font=dict(size=16, color="gray")
        )
        fig.update_layout(
            height=400,
            xaxis=dict(visible=False),
            yaxis=dict(visible=False)
        )
        return fig
    
    def create_crop_disease_heatmap(self) -> go.Figure:
        """Create a heatmap showing crop-disease relationships."""
        if self.df.empty:
            return self._create_empty_chart("No data available")
        
        # Get top crops and diseases for readability
        top_crops = self.df['Crop Name'].value_counts().head(15).index
        top_diseases = self.df['Disease Name'].value_counts().head(15).index
        
        # Filter data
        filtered_df = self.df[
            (self.df['Crop Name'].isin(top_crops)) & 
            (self.df['Disease Name'].isin(top_diseases))
        ]
        
        # Create pivot table
        heatmap_data = filtered_df.groupby(['Crop Name', 'Disease Name']).size().unstack(fill_value=0)
        
        fig = px.imshow(
            heatmap_data.values,
            x=heatmap_data.columns,
            y=heatmap_data.index,
            title="Crop-Disease Relationship Heatmap (Top 15 each)",
            labels=dict(x="Disease Name", y="Crop Name", color="Records"),
            color_continuous_scale='YlOrRd'
        )
        
        fig.update_layout(
            height=600,
            title_font_size=16,
            xaxis_tickangle=-45
        )
        
        return fig
