import pandas as pd
import streamlit as st
from typing import List, Dict, Optional
from fuzzywuzzy import fuzz, process

class DataHandler:
    def __init__(self, uploaded_file=None):
        """Initialize the data handler with uploaded CSV file."""
        if uploaded_file:
            self.df = pd.read_csv(uploaded_file)
            self._validate_data()
        else:
            self.df = None
    
    def _validate_data(self):
        """Validate that the CSV has required columns."""
        required_columns = [
            'Crop Name', 'Disease Name', 'Symptoms', 'Cause',
            'Organic Solution', 'Chemical Solution', 'Prevention Tips'
        ]
        
        if self.df is not None:
            missing_columns = [col for col in required_columns if col not in self.df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            # Clean data
            self.df = self.df.dropna(subset=['Crop Name', 'Disease Name'])
            self.df = self.df.fillna('Not specified')
        
            # Standardize text
            for col in ['Crop Name', 'Disease Name']:
                self.df[col] = self.df[col].str.strip().str.title()
    
    def get_data(self) -> pd.DataFrame:
        """Return the complete dataset."""
        return self.df.copy() if self.df is not None else pd.DataFrame()
    
    def search_by_crop(self, crop_name: str, fuzzy: bool = True) -> pd.DataFrame:
        """Search for diseases by crop name."""
        if self.df is None or crop_name.strip() == '':
            return pd.DataFrame()
        
        crop_name = crop_name.strip().title()
        
        if fuzzy:
            # Use fuzzy matching
            crop_names = self.df['Crop Name'].unique()
            matches = process.extract(crop_name, crop_names, limit=3, scorer=fuzz.ratio)
            matched_crops = [match[0] for match in matches if match[1] > 60]
            return self.df[self.df['Crop Name'].isin(matched_crops)]
        else:
            # Exact match
            return self.df[self.df['Crop Name'].str.contains(crop_name, case=False, na=False)]
    
    def search_by_disease(self, disease_name: str, fuzzy: bool = True) -> pd.DataFrame:
        """Search for information by disease name."""
        if self.df is None or disease_name.strip() == '':
            return pd.DataFrame()
        
        disease_name = disease_name.strip().title()
        
        if fuzzy:
            # Use fuzzy matching
            disease_names = self.df['Disease Name'].unique()
            matches = process.extract(disease_name, disease_names, limit=3, scorer=fuzz.ratio)
            matched_diseases = [match[0] for match in matches if match[1] > 60]
            return self.df[self.df['Disease Name'].isin(matched_diseases)]
        else:
            # Exact match
            return self.df[self.df['Disease Name'].str.contains(disease_name, case=False, na=False)]
    
    def get_autocomplete_suggestions(self, query: str, field: str = 'both') -> List[str]:
        """Get autocomplete suggestions for search."""
        if self.df is None or query.strip() == '':
            return []
        
        query = query.strip().lower()
        suggestions = []
        
        if field in ['crop', 'both']:
            crop_matches = self.df['Crop Name'].unique()
            crop_suggestions = [crop for crop in crop_matches 
                             if query in crop.lower()][:5]
            suggestions.extend(crop_suggestions)
        
        if field in ['disease', 'both']:
            disease_matches = self.df['Disease Name'].unique()
            disease_suggestions = [disease for disease in disease_matches 
                                 if query in disease.lower()][:5]
            suggestions.extend(disease_suggestions)
        
        return list(set(suggestions))[:10]  # Remove duplicates and limit
    
    def get_crop_list(self) -> List[str]:
        """Get list of all unique crops."""
        if self.df is None:
            return []
        return sorted(self.df['Crop Name'].unique().tolist())
    
    def get_disease_list(self) -> List[str]:
        """Get list of all unique diseases."""
        if self.df is None:
            return []
        return sorted(self.df['Disease Name'].unique().tolist())
    
    def search_by_symptoms(self, symptoms: str) -> pd.DataFrame:
        """Search by symptoms description."""
        if self.df is None or symptoms.strip() == '':
            return pd.DataFrame()
        
        # Search in symptoms column
        mask = self.df['Symptoms'].str.contains(symptoms, case=False, na=False)
        return self.df[mask]
    
    def get_disease_stats(self) -> Dict:
        """Get statistics about diseases in the dataset."""
        if self.df is None:
            return {}
        
        stats = {
            'total_records': len(self.df),
            'unique_crops': self.df['Crop Name'].nunique(),
            'unique_diseases': self.df['Disease Name'].nunique(),
            'top_diseases': self.df['Disease Name'].value_counts().head(10).to_dict(),
            'crops_per_disease': self.df.groupby('Disease Name')['Crop Name'].nunique().sort_values(ascending=False).head(10).to_dict(),
            'diseases_per_crop': self.df.groupby('Crop Name')['Disease Name'].nunique().sort_values(ascending=False).head(10).to_dict()
        }
        return stats
    
    def get_contextual_info(self, query: str) -> List[Dict]:
        """Get contextual information for chatbot queries."""
        if self.df is None:
            return []
        
        # Search across multiple columns
        query_lower = query.lower()
        relevant_rows = []
        
        # Search in all text columns
        text_columns = ['Crop Name', 'Disease Name', 'Symptoms', 'Cause']
        for _, row in self.df.iterrows():
            relevance_score = 0
            for col in text_columns:
                if query_lower in str(row[col]).lower():
                    relevance_score += 1
            
            if relevance_score > 0:
                relevant_rows.append({
                    'relevance': relevance_score,
                    'data': row.to_dict()
                })
        
        # Sort by relevance and return top 5
        relevant_rows.sort(key=lambda x: x['relevance'], reverse=True)
        return [item['data'] for item in relevant_rows[:5]]
