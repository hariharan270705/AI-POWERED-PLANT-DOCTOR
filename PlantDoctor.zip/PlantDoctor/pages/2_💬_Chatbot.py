import streamlit as st
import os
from utils.data_handler import DataHandler
from utils.chatbot import PlantDoctorChatbot
from utils.database import DatabaseManager
from utils.export_utils import ExportUtils
import pandas as pd

st.set_page_config(
    page_title="AI Chatbot - Smart Plant Doctor",
    page_icon="💬",
    layout="wide"
)

def main():
    st.title("💬 AI Plant Doctor Assistant")
    
    # Check if data is loaded
    if 'data_handler' not in st.session_state or st.session_state.data_handler is None:
        st.error("❌ Please upload your dataset first on the main page.")
        if st.button("Go to Main Page"):
            st.switch_page("app.py")
        return
    
    # Check for OpenAI API key
    if not os.getenv("OPENAI_API_KEY"):
        st.error("❌ OpenAI API key not found. Please set the OPENAI_API_KEY environment variable.")
        st.info("You can get an API key from https://platform.openai.com/api-keys")
        return
    
    data_handler = st.session_state.data_handler
    
    # Initialize chatbot
    try:
        if 'chatbot' not in st.session_state:
            st.session_state.chatbot = PlantDoctorChatbot()
    except Exception as e:
        st.error(f"❌ Error initializing chatbot: {str(e)}")
        return
    
    # Initialize chat history
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    # Sidebar with suggestions and options
    with st.sidebar:
        st.markdown("### 💡 Suggested Questions")
        
        sample_questions = [
            "What causes blight in potato?",
            "How do I treat tomato leaf curl organically?",
            "What are the symptoms of bacterial wilt?",
            "How can I prevent fungal diseases in my garden?",
            "What organic solutions work for aphid infestations?",
            "Why are my plant leaves turning yellow?",
            "How do I identify plant nutrient deficiencies?",
            "What's the best way to prevent root rot?"
        ]
        
        for question in sample_questions:
            if st.button(question, key=f"suggest_{hash(question)}"):
                st.session_state.current_question = question
                st.rerun()
        
        st.markdown("---")
        
        # Clear chat history
        if st.button("🗑️ Clear Chat History"):
            st.session_state.chat_history = []
            st.rerun()
        
        # Export chat history
        if st.session_state.chat_history:
            st.markdown("### 📤 Export Chat")
            
            # Prepare chat data for export
            chat_df = pd.DataFrame([
                {
                    'Question': item['question'],
                    'Response': item['response'],
                    'Timestamp': item.get('timestamp', 'N/A')
                }
                for item in st.session_state.chat_history
            ])
            
            ExportUtils.download_csv_button(
                chat_df,
                "chat_history.csv",
                "📊 Export as CSV"
            )
            
            # Create combined response for PDF
            combined_content = ""
            for item in st.session_state.chat_history:
                combined_content += f"Q: {item['question']}\n\nA: {item['response']}\n\n" + "="*50 + "\n\n"
            
            if combined_content:
                pdf_data = pd.DataFrame([{'Chat_Content': combined_content}])
                ExportUtils.download_pdf_button(
                    pdf_data,
                    "Plant Doctor Chat History",
                    "chat_history.pdf",
                    "📄 Export as PDF",
                    query="Chat History Export",
                    response=combined_content
                )
    
    # Main chat interface
    st.markdown("### Ask the AI Plant Doctor")
    st.markdown("Ask any question about plant diseases, symptoms, treatments, or prevention. The AI will search through your uploaded dataset to provide accurate answers.")
    
    # Handle suggested question or quick chat from image detection
    user_input = ""
    if hasattr(st.session_state, 'current_question'):
        user_input = st.session_state.current_question
        del st.session_state.current_question
    elif hasattr(st.session_state, 'quick_chat_query'):
        user_input = st.session_state.quick_chat_query
        del st.session_state.quick_chat_query
        st.info(f"💬 Quick chat initiated: {user_input}")
    
    # Chat input
    with st.form("chat_form", clear_on_submit=True):
        user_question = st.text_area(
            "Your question:",
            value=user_input,
            placeholder="e.g., How do I treat rust disease in wheat?",
            height=100
        )
        
        col1, col2 = st.columns([1, 4])
        with col1:
            submit_button = st.form_submit_button("🚀 Ask", use_container_width=True)
        with col2:
            st.markdown("*Press Ctrl+Enter to submit*")
    
    # Process question
    if submit_button and user_question.strip():
        with st.spinner("🤔 Thinking..."):
            try:
                # Analyze query intent
                query_analysis = st.session_state.chatbot.analyze_query_intent(user_question)
                
                # Get relevant data from dataset
                relevant_data = data_handler.get_contextual_info(user_question)
                
                # Get AI response
                ai_response = st.session_state.chatbot.get_response(user_question, relevant_data)
                
                # Add to chat history
                from datetime import datetime
                st.session_state.chat_history.append({
                    'question': user_question,
                    'response': ai_response,
                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    'relevant_data': relevant_data
                })
                
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error processing your question: {str(e)}")
    
    # Display chat history
    if st.session_state.chat_history:
        st.markdown("### 💬 Conversation History")
        
        # Display conversations in reverse order (most recent first)
        for idx, chat in enumerate(reversed(st.session_state.chat_history)):
            with st.container():
                # User question
                st.markdown(f"**🧑 You ({chat.get('timestamp', 'Unknown time')}):**")
                st.markdown(f"> {chat['question']}")
                
                # AI response
                st.markdown("**🤖 AI Plant Doctor:**")
                st.markdown(chat['response'])
                
                # Show relevant data sources if available
                if chat.get('relevant_data'):
                    with st.expander(f"📚 Data sources used ({len(chat['relevant_data'])} records)"):
                        for i, data in enumerate(chat['relevant_data'][:3], 1):
                            st.markdown(f"**Source {i}:** {data.get('Crop Name', 'N/A')} - {data.get('Disease Name', 'N/A')}")
                
                # Export individual conversation
                col1, col2 = st.columns(2)
                with col1:
                    # Create DataFrame for this conversation
                    conv_df = pd.DataFrame([{
                        'Question': chat['question'],
                        'Response': chat['response'],
                        'Timestamp': chat.get('timestamp', 'N/A')
                    }])
                    
                    ExportUtils.download_csv_button(
                        conv_df,
                        f"conversation_{idx+1}.csv",
                        f"📊 Export Conversation {len(st.session_state.chat_history)-idx}"
                    )
                
                with col2:
                    ExportUtils.download_pdf_button(
                        pd.DataFrame(),  # Empty DF since we'll use custom content
                        f"Plant Doctor Conversation {len(st.session_state.chat_history)-idx}",
                        f"conversation_{idx+1}.pdf",
                        f"📄 Export Conversation {len(st.session_state.chat_history)-idx}",
                        query=chat['question'],
                        response=chat['response']
                    )
                
                st.markdown("---")
    
    else:
        st.info("👋 Welcome! Ask me any question about plant diseases and I'll help you find answers based on your dataset.")
        
        # Show example queries
        st.markdown("### 🎯 Example Questions You Can Ask:")
        examples = [
            "What are the early symptoms of tomato blight?",
            "How do I prevent fungal diseases in humid weather?",
            "What organic treatments work best for aphids?",
            "Why are my cucumber leaves turning yellow?",
            "How do I treat bacterial spot on peppers?",
            "What causes powdery mildew and how to prevent it?"
        ]
        
        for example in examples:
            st.markdown(f"• {example}")

if __name__ == "__main__":
    main()
