import streamlit as st
import pandas as pd
from utils.data_handler import DataHandler
from utils.database import DatabaseManager
from utils.export_utils import ExportUtils

st.set_page_config(
    page_title="Search - Smart Plant Doctor",
    page_icon="🔍",
    layout="wide"
)

def main():
    st.title("🔍 Search Plant Diseases")
    
    # Initialize database manager
    if 'db_manager' not in st.session_state:
        st.session_state.db_manager = DatabaseManager()
    
    db_manager = st.session_state.db_manager
    
    # Check if data is loaded (either in session or database)
    if ('data_handler' not in st.session_state or st.session_state.data_handler is None) and len(db_manager.get_all_diseases()) == 0:
        st.error("❌ Please upload your dataset first on the main page.")
        if st.button("Go to Main Page"):
            st.switch_page("app.py")
        return
    
    # Use database as primary source, fall back to session data
    if len(db_manager.get_all_diseases()) > 0:
        st.info("📊 Using database-stored data for enhanced search capabilities")
        use_database = True
        data_handler = st.session_state.get('data_handler')  # May be None
    else:
        data_handler = st.session_state.data_handler
        use_database = False
    
    # Handle quick search from image detection
    initial_crop_query = ""
    if hasattr(st.session_state, 'quick_search_crop'):
        initial_crop_query = st.session_state.quick_search_crop
        del st.session_state.quick_search_crop
        st.info(f"🔍 Quick search initiated for: {initial_crop_query}")
    
    # Search interface
    st.markdown("### Search Options")
    
    # Create tabs for different search types
    tab1, tab2, tab3 = st.tabs(["🌱 Search by Crop", "🦠 Search by Disease", "🔍 Search by Symptoms"])
    
    with tab1:
        st.markdown("#### Find diseases affecting a specific crop")
        
        # Get crop suggestions from database or data handler
        if use_database:
            crop_list = db_manager.get_unique_crops()
        else:
            crop_list = data_handler.get_crop_list()
        
        col1, col2 = st.columns([3, 1])
        with col1:
            # Set initial value if coming from quick search
            initial_index = 0
            if initial_crop_query and initial_crop_query in crop_list:
                initial_index = crop_list.index(initial_crop_query) + 1
            
            crop_query = st.selectbox(
                "Select or type a crop name:",
                options=[""] + crop_list,
                index=initial_index,
                help="Choose from the dropdown or start typing to filter"
            )
        
        with col2:
            fuzzy_search_crop = st.checkbox("Enable fuzzy search", value=True, key="crop_fuzzy")
        
        if crop_query:
            with st.spinner("Searching..."):
                if use_database:
                    # Log search query
                    db_manager.log_user_query(crop_query, 'search', session_id=st.get_option("browser.serverAddress"))
                    results_list = db_manager.search_diseases(crop_query, 'crop')
                    results = pd.DataFrame(results_list) if results_list else pd.DataFrame()
                else:
                    results = data_handler.search_by_crop(crop_query, fuzzy=fuzzy_search_crop)
            
            if not results.empty:
                st.success(f"Found {len(results)} result(s) for '{crop_query}'")
                display_results(results, data_handler, f"crop_{crop_query}")
            else:
                st.warning(f"No results found for '{crop_query}'. Try enabling fuzzy search or check spelling.")
    
    with tab2:
        st.markdown("#### Find information about a specific disease")
        
        disease_list = data_handler.get_disease_list()
        
        col1, col2 = st.columns([3, 1])
        with col1:
            disease_query = st.selectbox(
                "Select or type a disease name:",
                options=[""] + disease_list,
                index=0,
                help="Choose from the dropdown or start typing to filter"
            )
        
        with col2:
            fuzzy_search_disease = st.checkbox("Enable fuzzy search", value=True, key="disease_fuzzy")
        
        if disease_query:
            with st.spinner("Searching..."):
                results = data_handler.search_by_disease(disease_query, fuzzy=fuzzy_search_disease)
            
            if not results.empty:
                st.success(f"Found {len(results)} result(s) for '{disease_query}'")
                display_results(results, data_handler, f"disease_{disease_query}")
            else:
                st.warning(f"No results found for '{disease_query}'. Try enabling fuzzy search or check spelling.")
    
    with tab3:
        st.markdown("#### Search by symptoms description")
        
        symptoms_query = st.text_area(
            "Describe the symptoms you're observing:",
            placeholder="e.g., yellowing leaves, brown spots, wilting...",
            height=100
        )
        
        if st.button("Search by Symptoms") and symptoms_query:
            with st.spinner("Searching..."):
                results = data_handler.search_by_symptoms(symptoms_query)
            
            if not results.empty:
                st.success(f"Found {len(results)} result(s) matching your symptoms")
                display_results(results, data_handler, f"symptoms_{symptoms_query[:20]}")
            else:
                st.warning("No results found matching those symptoms. Try different keywords.")

def display_results(results: pd.DataFrame, data_handler: DataHandler, query_id: str):
    """Display search results in an organized format."""
    
    # Export options at the top
    st.markdown("### Export Results")
    col1, col2 = st.columns(2)
    
    with col1:
        ExportUtils.download_csv_button(
            results,
            f"search_results_{query_id}.csv",
            "📊 Download as CSV"
        )
    
    with col2:
        ExportUtils.download_pdf_button(
            results,
            f"Plant Disease Search Results - {query_id}",
            f"search_results_{query_id}.pdf",
            "📄 Download as PDF"
        )
    
    st.markdown("---")
    
    # Display results
    st.markdown("### Search Results")
    
    for record_idx, (idx, row) in enumerate(results.iterrows()):
        with st.expander(f"🌱 {row['Crop Name']} - {row['Disease Name']}", expanded=record_idx==0):
            
            # Create columns for better layout
            col1, col2 = st.columns([1, 1])
            
            with col1:
                st.markdown("**🔍 Symptoms:**")
                st.write(row['Symptoms'])
                
                st.markdown("**⚠️ Cause:**")
                st.write(row['Cause'])
            
            with col2:
                st.markdown("**🌿 Organic Solution:**")
                st.write(row['Organic Solution'])
                
                st.markdown("**⚗️ Chemical Solution:**")
                st.write(row['Chemical Solution'])
            
            st.markdown("**🛡️ Prevention Tips:**")
            st.write(row['Prevention Tips'])
            
            # Individual export buttons
            st.markdown("---")
            col_exp1, col_exp2 = st.columns(2)
            
            with col_exp1:
                single_record = pd.DataFrame([row])
                ExportUtils.download_csv_button(
                    single_record,
                    f"{row['Crop Name']}_{row['Disease Name']}.csv",
                    f"📊 Export this record as CSV"
                )
            
            with col_exp2:
                ExportUtils.download_pdf_button(
                    single_record,
                    f"{row['Crop Name']} - {row['Disease Name']} Information",
                    f"{row['Crop Name']}_{row['Disease Name']}.pdf",
                    f"📄 Export this record as PDF"
                )
    
    # Summary statistics
    if len(results) > 1:
        st.markdown("### Summary")
        st.info(f"📊 Found {len(results)} records covering {results['Crop Name'].nunique()} unique crops and {results['Disease Name'].nunique()} unique diseases.")

if __name__ == "__main__":
    main()
