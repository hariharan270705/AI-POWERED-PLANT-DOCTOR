import streamlit as st
import pandas as pd
from utils.data_handler import DataHandler
from utils.database import DatabaseManager
from utils.visualizations import PlantDataVisualizer
from utils.export_utils import ExportUtils

st.set_page_config(
    page_title="Analytics - Smart Plant Doctor",
    page_icon="📊",
    layout="wide"
)

def main():
    st.title("📊 Plant Disease Analytics")
    
    # Initialize database manager
    if 'db_manager' not in st.session_state:
        st.session_state.db_manager = DatabaseManager()
    
    db_manager = st.session_state.db_manager
    
    # Check if data is loaded (either in session or database)
    if ('data_handler' not in st.session_state or st.session_state.data_handler is None) and len(db_manager.get_all_diseases()) == 0:
        st.error("❌ Please upload your dataset first on the main page.")
        if st.button("Go to Main Page"):
            st.switch_page("app.py")
        return
    
    # Use database as primary source, fall back to session data
    if len(db_manager.get_all_diseases()) > 0:
        st.info("📊 Using database analytics with enhanced tracking capabilities")
        use_database = True
        data_handler = st.session_state.get('data_handler')  # May be None
        
        # Show database analytics
        show_database_analytics(db_manager)
    else:
        data_handler = st.session_state.data_handler
        visualizer = PlantDataVisualizer(data_handler)
        use_database = False
        
        # Show traditional analytics
        show_traditional_analytics(visualizer)

def show_database_analytics(db_manager):
    """Show analytics using database data."""
    # Get analytics data
    analytics_data = db_manager.get_analytics_data()
    
    # Display key metrics
    st.markdown("### 📈 Key Statistics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Total Diseases",
            analytics_data.get('total_diseases', 0),
            help="Total number of diseases in database"
        )
    
    with col2:
        st.metric(
            "User Queries",
            analytics_data.get('total_queries', 0),
            help="Total number of user queries logged"
        )
    
    with col3:
        st.metric(
            "Image Analyses",
            analytics_data.get('total_image_analyses', 0),
            help="Total number of image analyses performed"
        )
    
    with col4:
        unique_crops = len(db_manager.get_unique_crops())
        st.metric(
            "Unique Crops",
            unique_crops,
            help="Number of different crops in database"
        )
    
    # Get all diseases for visualization
    all_diseases = db_manager.get_all_diseases()
    if all_diseases:
        df = pd.DataFrame(all_diseases)
        
        # Crop distribution
        st.markdown("### 🌱 Crop Distribution")
        crop_counts = df['Crop Name'].value_counts()
        
        import plotly.express as px
        fig_crops = px.bar(
            x=crop_counts.index[:10],
            y=crop_counts.values[:10],
            title="Top 10 Crops by Disease Count",
            labels={'x': 'Crop Name', 'y': 'Number of Diseases'}
        )
        st.plotly_chart(fig_crops, use_container_width=True)

def show_traditional_analytics(visualizer):
    """Show traditional analytics using data handler."""
    # Get summary metrics
    metrics = visualizer.create_summary_metrics()
    
    if not metrics:
        st.error("No data available for analysis.")
        return
    
    # Display key metrics
    st.markdown("### 📈 Key Statistics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Total Records",
            metrics.get('total_records', 0),
            help="Total number of disease records in the dataset"
        )
    
    with col2:
        st.metric(
            "Unique Crops",
            metrics.get('unique_crops', 0),
            help="Number of different crops covered"
        )
    
    with col3:
        st.metric(
            "Unique Diseases",
            metrics.get('unique_diseases', 0),
            help="Number of different diseases documented"
        )
    
    with col4:
        st.metric(
            "Avg Diseases/Crop",
            metrics.get('avg_diseases_per_crop', 0),
            help="Average number of diseases per crop"
        )
    
    # Additional metrics in expandable section
    with st.expander("🔍 More Statistics"):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("**Most Affected Crop:**")
            st.write(f"🌱 {metrics.get('most_affected_crop', 'N/A')}")
        
        with col2:
            st.markdown("**Most Common Disease:**")
            st.write(f"🦠 {metrics.get('most_common_disease', 'N/A')}")
        
        with col3:
            st.markdown("**Crops with Organic Solutions:**")
            st.write(f"🌿 {metrics.get('crops_with_organic_solutions', 0)}")
    
    st.markdown("---")
    
    # Visualization tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🦠 Disease Analysis", 
        "🌱 Crop Analysis", 
        "💊 Treatment Analysis",
        "🔥 Relationship Maps"
    ])
    
    with tab1:
        st.markdown("### Disease Frequency Analysis")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Most common diseases chart
            disease_chart = visualizer.create_disease_frequency_chart()
            st.plotly_chart(disease_chart, use_container_width=True)
        
        with col2:
            # Disease category distribution
            category_chart = visualizer.create_disease_distribution_pie()
            st.plotly_chart(category_chart, use_container_width=True)
        
        # Disease statistics table
        st.markdown("### Top 10 Diseases by Occurrence")
        stats = data_handler.get_disease_stats()
        if stats.get('top_diseases'):
            disease_df = pd.DataFrame(list(stats['top_diseases'].items()), 
                                    columns=['Disease Name', 'Occurrences'])
            st.dataframe(disease_df, use_container_width=True)
            
            # Export disease stats
            ExportUtils.download_csv_button(
                disease_df,
                "top_diseases_statistics.csv",
                "📊 Export Disease Statistics"
            )
    
    with tab2:
        st.markdown("### Crop Diversity Analysis")
        
        # Crops with most diseases
        crop_chart = visualizer.create_crop_diversity_chart()
        st.plotly_chart(crop_chart, use_container_width=True)
        
        # Crop statistics
        st.markdown("### Crops by Disease Count")
        stats = data_handler.get_disease_stats()
        if stats.get('diseases_per_crop'):
            crop_df = pd.DataFrame(list(stats['diseases_per_crop'].items()), 
                                 columns=['Crop Name', 'Number of Diseases'])
            st.dataframe(crop_df, use_container_width=True)
            
            # Export crop stats
            ExportUtils.download_csv_button(
                crop_df,
                "crop_disease_statistics.csv",
                "📊 Export Crop Statistics"
            )
    
    with tab3:
        st.markdown("### Treatment Solution Analysis")
        
        # Solution availability analysis
        solution_chart = visualizer.create_solution_type_analysis()
        st.plotly_chart(solution_chart, use_container_width=True)
        
        # Create treatment summary
        df = data_handler.get_data()
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Organic Solutions Available")
            organic_count = len(df[
                (df['Organic Solution'].str.len() > 10) & 
                (~df['Organic Solution'].str.contains('not specified', case=False, na=False))
            ])
            st.metric("Records with Organic Solutions", organic_count)
            
            # Show percentage
            percentage = (organic_count / len(df)) * 100 if len(df) > 0 else 0
            st.write(f"📊 {percentage:.1f}% of all records")
        
        with col2:
            st.markdown("#### Chemical Solutions Available")
            chemical_count = len(df[
                (df['Chemical Solution'].str.len() > 10) & 
                (~df['Chemical Solution'].str.contains('not specified', case=False, na=False))
            ])
            st.metric("Records with Chemical Solutions", chemical_count)
            
            # Show percentage
            percentage = (chemical_count / len(df)) * 100 if len(df) > 0 else 0
            st.write(f"📊 {percentage:.1f}% of all records")
    
    with tab4:
        st.markdown("### Crop-Disease Relationship Analysis")
        
        # Scatter plot showing disease impact
        scatter_chart = visualizer.create_crops_per_disease_scatter()
        st.plotly_chart(scatter_chart, use_container_width=True)
        
        # Heatmap
        st.markdown("### Crop-Disease Heatmap")
        heatmap_chart = visualizer.create_crop_disease_heatmap()
        st.plotly_chart(heatmap_chart, use_container_width=True)
        
        # Relationship insights
        st.markdown("### Key Insights")
        
        df = data_handler.get_data()
        
        # Find diseases affecting multiple crops
        diseases_multiple_crops = df.groupby('Disease Name')['Crop Name'].nunique().sort_values(ascending=False)
        
        # Find crops with multiple diseases
        crops_multiple_diseases = df.groupby('Crop Name')['Disease Name'].nunique().sort_values(ascending=False)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Most Cross-Crop Diseases")
            top_cross_diseases = diseases_multiple_crops.head(5)
            for disease, count in top_cross_diseases.items():
                st.write(f"🦠 **{disease}**: affects {count} different crops")
        
        with col2:
            st.markdown("#### Most Disease-Prone Crops")
            top_prone_crops = crops_multiple_diseases.head(5)
            for crop, count in top_prone_crops.items():
                st.write(f"🌱 **{crop}**: {count} different diseases")
    
    # Export comprehensive analytics report
    st.markdown("---")
    st.markdown("### 📤 Export Analytics Report")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Create comprehensive summary for export
        summary_df = ExportUtils.create_summary_export(data_handler)
        ExportUtils.download_csv_button(
            summary_df,
            "plant_disease_analytics_summary.csv",
            "📊 Download Analytics Summary (CSV)"
        )
    
    with col2:
        # Export complete dataset with analytics
        complete_df = data_handler.get_data()
        ExportUtils.download_pdf_button(
            complete_df.head(10),  # Limit for PDF size
            "Plant Disease Analytics Report",
            "analytics_report.pdf",
            "📄 Download Analytics Report (PDF)",
            query="Complete Analytics Report",
            response="This report contains comprehensive analytics of the plant disease dataset including disease frequency, crop analysis, and treatment statistics."
        )

if __name__ == "__main__":
    main()
