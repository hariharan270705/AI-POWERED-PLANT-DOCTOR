import streamlit as st
import pandas as pd
from PIL import Image, ImageDraw
import io
import numpy as np
import json
from utils.data_handler import DataHandler
from utils.database import DatabaseManager
from utils.image_classifier import PlantDiseaseClassifier
from utils.export_utils import ExportUtils

st.set_page_config(
    page_title="Image Detection - Smart Plant Doctor",
    page_icon="📸",
    layout="wide"
)

def main():
    st.title("📸 Plant Disease Detection from Images")
    st.markdown("Upload a plant leaf image to detect diseases using AI-powered image analysis")
    
    # Check if data is loaded
    if 'data_handler' not in st.session_state or st.session_state.data_handler is None:
        st.error("❌ Please upload your dataset first on the main page.")
        if st.button("Go to Main Page"):
            st.switch_page("app.py")
        return
    
    data_handler = st.session_state.data_handler
    
    # Initialize image classifier
    if 'image_classifier' not in st.session_state:
        with st.spinner("Loading AI model..."):
            st.session_state.image_classifier = PlantDiseaseClassifier()
    
    classifier = st.session_state.image_classifier
    
    # Create two columns
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("### 📤 Upload Plant Image")
        
        # File uploader
        uploaded_file = st.file_uploader(
            "Choose a plant leaf image",
            type=['jpg', 'jpeg', 'png', 'bmp'],
            help="Upload a clear image of a plant leaf showing disease symptoms"
        )
        
        # Image enhancement option
        enhance_image = st.checkbox(
            "✨ Enhance image quality",
            value=True,
            help="Apply image processing to improve detection accuracy"
        )
        
        if uploaded_file is not None:
            try:
                # Load and display image
                image = Image.open(uploaded_file)
                
                # Display original image
                st.markdown("#### Original Image")
                st.image(image, caption="Uploaded Image", use_container_width=True)
                
                # Image enhancement
                if enhance_image:
                    enhanced_image = classifier.enhance_image_quality(image)
                    st.markdown("#### Enhanced Image")
                    st.image(enhanced_image, caption="Enhanced Image", use_container_width=True)
                    analysis_image = enhanced_image
                else:
                    analysis_image = image
                
                # Image analysis button
                if st.button("🔍 Analyze Disease", type="primary", use_container_width=True):
                    analyze_image(analysis_image, classifier, data_handler)
                    
            except Exception as e:
                st.error(f"Error loading image: {str(e)}")
    
    with col2:
        st.markdown("### 📋 Analysis Guidelines")
        
        st.markdown("""
        **For best results:**
        - Use clear, well-lit images
        - Focus on diseased areas of the leaf
        - Avoid blurry or dark images
        - Include multiple leaves if possible
        - Ensure the leaf fills most of the frame
        """)
        
        st.markdown("### 🌱 Supported Crops")
        supported_crops = [
            "🍎 Apple", "🫐 Blueberry", "🍒 Cherry", "🌽 Corn",
            "🍇 Grape", "🍊 Orange", "🍑 Peach", "🌶️ Pepper",
            "🥔 Potato", "🫐 Raspberry", "🌱 Soybean", "🎃 Squash",
            "🍓 Strawberry", "🍅 Tomato"
        ]
        
        for crop in supported_crops:
            st.markdown(f"• {crop}")
        
        # Demo image generator
        st.markdown("### 🧪 Test with Demo Image")
        demo_options = [
            "Healthy Leaf",
            "Brown Spots (Blight)",
            "Yellow Areas (Virus)",
            "White Patches (Mildew)"
        ]
        
        selected_demo = st.selectbox("Generate test image:", ["None"] + demo_options)
        
        if selected_demo != "None" and st.button("Generate Demo Image"):
            demo_image = create_demo_image(selected_demo)
            st.image(demo_image, caption=f"Demo: {selected_demo}", use_container_width=True)
            
            if st.button("Analyze Demo Image", type="primary"):
                analyze_image(demo_image, classifier, data_handler)

def create_demo_image(demo_type):
    """Create a demo leaf image with different disease characteristics."""
    # Create a 400x400 green leaf base
    img = Image.new('RGB', (400, 400), (34, 139, 34))  # Forest green
    draw = ImageDraw.Draw(img)
    
    # Draw leaf shape
    draw.ellipse([50, 100, 350, 300], fill=(50, 205, 50))  # Lime green leaf
    
    if demo_type == "Brown Spots (Blight)":
        # Add brown spots
        for i in range(8):
            x = np.random.randint(80, 320)
            y = np.random.randint(130, 270)
            size = np.random.randint(15, 35)
            draw.ellipse([x, y, x+size, y+size], fill=(139, 69, 19))  # Brown
    
    elif demo_type == "Yellow Areas (Virus)":
        # Add yellow areas
        for i in range(5):
            x = np.random.randint(80, 320)
            y = np.random.randint(130, 270)
            size = np.random.randint(25, 50)
            draw.ellipse([x, y, x+size, y+size], fill=(255, 255, 0))  # Yellow
    
    elif demo_type == "White Patches (Mildew)":
        # Add white patches
        for i in range(6):
            x = np.random.randint(80, 320)
            y = np.random.randint(130, 270)
            size = np.random.randint(20, 40)
            draw.ellipse([x, y, x+size, y+size], fill=(255, 255, 255))  # White
    
    return img

def analyze_image(image, classifier, data_handler):
    """Analyze the uploaded image and display results."""
    
    with st.spinner("🤖 Analyzing image with AI..."):
        # Get prediction from classifier
        result = classifier.predict_disease(image)
    
    if result.get('error'):
        st.error(f"Analysis failed: {result['error']}")
        return
    
    # Display results
    st.markdown("---")
    st.markdown("## 🎯 Detection Results")
    
    prediction = result['prediction']
    confidence = result['confidence']
    
    # Log to database if available
    if 'db_manager' in st.session_state:
        try:
            st.session_state.db_manager.log_image_analysis(
                image_name="uploaded_image",
                predicted_disease=prediction['disease'],
                confidence_score=confidence,
                crop_type=prediction['crop'],
                analysis_result=json.dumps(result['top_predictions']),
                session_id=st.get_option("browser.serverAddress")
            )
        except Exception as e:
            st.warning(f"Database logging failed: {str(e)}")
    
    # Main prediction
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown(f"### 🌱 **{prediction['crop']}**")
        
        if prediction['disease'].lower() == 'healthy':
            st.success(f"✅ **Status: {prediction['disease']}**")
            st.markdown("Great news! Your plant appears to be healthy.")
        else:
            st.warning(f"⚠️ **Disease Detected: {prediction['disease']}**")
    
    with col2:
        # Confidence meter
        st.metric(
            "Confidence Score", 
            f"{confidence:.1%}",
            help="How confident the AI is about this prediction"
        )
        
        # Confidence indicator
        if confidence > 0.8:
            st.success("High confidence")
        elif confidence > 0.6:
            st.warning("Medium confidence")
        else:
            st.error("Low confidence")
    
    # Show top predictions
    if len(result['top_predictions']) > 1:
        st.markdown("### 🏆 Top 5 Predictions")
        
        predictions_data = []
        for i, pred in enumerate(result['top_predictions'][:5]):
            predictions_data.append({
                'Rank': i + 1,
                'Crop': pred['crop'],
                'Disease': pred['disease'],
                'Confidence': f"{pred['confidence']:.1%}"
            })
        
        pred_df = pd.DataFrame(predictions_data)
        st.dataframe(pred_df, use_container_width=True, hide_index=True)
    
    # Get detailed information from CSV
    if prediction['disease'].lower() != 'healthy':
        detailed_info = classifier.get_disease_info_from_csv(
            prediction['crop'], 
            prediction['disease'], 
            data_handler
        )
        
        if detailed_info:
            display_disease_details(detailed_info, prediction)
        else:
            st.info("💡 No detailed information found in dataset for this specific disease. Try searching manually in the Search page.")
    
    # Export results
    st.markdown("---")
    st.markdown("### 📤 Export Results")
    
    # Prepare export data
    export_data = pd.DataFrame([{
        'Analyzed_Crop': prediction['crop'],
        'Detected_Disease': prediction['disease'],
        'Confidence_Score': f"{confidence:.1%}",
        'Analysis_Date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
        'Status': 'Healthy' if prediction['disease'].lower() == 'healthy' else 'Disease Detected'
    }])
    
    col1, col2 = st.columns(2)
    
    with col1:
        ExportUtils.download_csv_button(
            export_data,
            f"disease_detection_results.csv",
            "📊 Download Results (CSV)"
        )
    
    with col2:
        # Include detailed info in PDF if available
        pdf_content = f"Image Analysis Results\n\nCrop: {prediction['crop']}\nDisease: {prediction['disease']}\nConfidence: {confidence:.1%}"
        
        if 'detailed_info' in locals() and detailed_info:
            pdf_content += f"\n\nDetailed Information:\nSymptoms: {detailed_info.get('Symptoms', 'N/A')}\nCause: {detailed_info.get('Cause', 'N/A')}\nOrganic Solution: {detailed_info.get('Organic Solution', 'N/A')}\nChemical Solution: {detailed_info.get('Chemical Solution', 'N/A')}\nPrevention: {detailed_info.get('Prevention Tips', 'N/A')}"
        
        ExportUtils.download_pdf_button(
            export_data,
            "Plant Disease Detection Report",
            f"disease_detection_report.pdf",
            "📄 Download Report (PDF)",
            query=f"Image analysis of {prediction['crop']}",
            response=pdf_content
        )

def display_disease_details(disease_info, prediction):
    """Display detailed disease information from the CSV dataset."""
    
    st.markdown("---")
    st.markdown("## 📚 Detailed Disease Information")
    
    # Disease overview
    st.markdown(f"### 🦠 {disease_info.get('Disease Name', 'Unknown Disease')}")
    st.markdown(f"**Affected Crop:** {disease_info.get('Crop Name', 'Unknown')}")
    
    # Create tabs for different information types
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔍 Symptoms & Cause", 
        "🌿 Organic Solutions", 
        "⚗️ Chemical Solutions", 
        "🛡️ Prevention"
    ])
    
    with tab1:
        st.markdown("#### Symptoms")
        st.write(disease_info.get('Symptoms', 'No symptom information available'))
        
        st.markdown("#### Cause")
        st.write(disease_info.get('Cause', 'No cause information available'))
    
    with tab2:
        st.markdown("#### Organic Treatment Options")
        organic_solution = disease_info.get('Organic Solution', 'No organic solution information available')
        st.write(organic_solution)
        
        if organic_solution and len(organic_solution) > 20:
            st.success("✅ Organic solutions are available for this disease")
        else:
            st.info("ℹ️ Limited organic solution information available")
    
    with tab3:
        st.markdown("#### Chemical Treatment Options")
        chemical_solution = disease_info.get('Chemical Solution', 'No chemical solution information available')
        st.write(chemical_solution)
        
        if chemical_solution and len(chemical_solution) > 20:
            st.success("✅ Chemical solutions are available for this disease")
        else:
            st.info("ℹ️ Limited chemical solution information available")
        
        st.warning("⚠️ Always follow label instructions and local regulations when using chemical treatments")
    
    with tab4:
        st.markdown("#### Prevention Tips")
        prevention_tips = disease_info.get('Prevention Tips', 'No prevention information available')
        st.write(prevention_tips)
        
        if prevention_tips and len(prevention_tips) > 20:
            st.success("✅ Prevention strategies are available")
        else:
            st.info("ℹ️ Limited prevention information available")
    
    # Quick action buttons
    st.markdown("---")
    st.markdown("### 🚀 Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🔍 Search for similar diseases"):
            # Store search query in session state
            st.session_state.quick_search_crop = disease_info.get('Crop Name', '')
            st.switch_page("pages/1_🔍_Search.py")
    
    with col2:
        if st.button("💬 Ask AI about treatment"):
            # Store chatbot query in session state  
            st.session_state.quick_chat_query = f"How do I treat {disease_info.get('Disease Name', '')} in {disease_info.get('Crop Name', '')}?"
            st.switch_page("pages/2_💬_Chatbot.py")
    
    with col3:
        # Export detailed info
        detailed_df = pd.DataFrame([disease_info])
        ExportUtils.download_pdf_button(
            detailed_df,
            f"{disease_info.get('Crop Name', 'Plant')} - {disease_info.get('Disease Name', 'Disease')} Information",
            f"detailed_disease_info.pdf",
            "📄 Export Details"
        )

if __name__ == "__main__":
    main()