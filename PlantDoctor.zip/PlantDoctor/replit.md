# Smart Plant Doctor - Disease Detection & Cure Assistant

## Overview

Smart Plant Doctor is a comprehensive Streamlit-based web application designed to assist users in identifying and treating plant diseases through multiple approaches. The application provides an AI-powered platform featuring:

1. **CSV Data Upload & Management** - Upload and process plant disease datasets
2. **Multi-Search Functionality** - Search by crop, disease, or symptoms with fuzzy matching
3. **AI Chatbot Assistant** - OpenAI-powered conversational interface for plant disease queries
4. **Image-Based Disease Detection** - CNN-powered image analysis for disease identification from leaf photos
5. **Data Analytics Dashboard** - Interactive visualizations and insights
6. **Export Capabilities** - PDF and CSV export functionality

The system is built around a CSV dataset containing information about 100+ crops, their diseases, symptoms, causes, and treatment solutions, enhanced with machine learning image classification capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit - A Python-based web framework for data applications
- **Multi-page Architecture**: The application uses Streamlit's native multi-page functionality with separate Python files for different features
- **Responsive Design**: Custom CSS styling for mobile responsiveness and improved UI/UX
- **Component Structure**: Modular design with reusable utilities and clear separation of concerns

### Backend Architecture
- **Language**: Python
- **Structure**: Utility-based modular architecture with separate modules for different functionalities
- **Data Processing**: Pandas for data manipulation and analysis
- **AI Integration**: OpenAI GPT-4o for chatbot functionality
- **Search Engine**: FuzzyWuzzy for intelligent text matching and search capabilities
- **Database Integration**: PostgreSQL with SQLAlchemy ORM for persistent data storage

### Data Storage Solutions
- **PostgreSQL Database**: Primary persistent storage for plant disease data, user queries, and image analysis logs
- **Database Models**: PlantDisease, UserQuery, and ImageAnalysis tables with proper relationships
- **Session Management**: Streamlit's session state combined with database persistence
- **Data Validation**: Built-in validation for required columns and data cleaning processes
- **Enhanced Analytics**: Database-driven analytics with query logging and usage tracking

## Key Components

### 1. Main Application (app.py)
- Entry point and data upload interface
- Session state initialization
- Custom CSS styling for improved UI

### 2. Search Module (pages/1_🔍_Search.py)
- Multi-tab search interface (by crop, disease, symptoms)
- Fuzzy search capabilities
- Real-time filtering and suggestions
- Export functionality for search results

### 3. AI Chatbot (pages/2_💬_Chatbot.py)
- OpenAI GPT-4o powered conversational interface
- Context-aware responses based on uploaded dataset
- Chat history management
- Sample question suggestions
- Quick chat integration from image detection

### 4. Image-Based Disease Detection (pages/4_📸_Image_Detection.py)
- CNN-based plant disease classification from leaf images
- Support for 38 plant disease classes across 14 crop types
- Image preprocessing and enhancement capabilities
- Integration with CSV dataset for detailed disease information
- Confidence scoring and top-5 predictions display
- Direct integration with search and chatbot features

### 5. Analytics Dashboard (pages/3_📊_Analytics.py)
- Data visualization and insights
- Summary statistics and metrics
- Interactive charts and graphs

### 5. Utility Modules
- **DataHandler**: Core data processing and search functionality
- **PlantDoctorChatbot**: AI chatbot implementation with OpenAI integration
- **ExportUtils**: PDF and CSV export capabilities
- **PlantDataVisualizer**: Chart and graph generation using Plotly

## Data Flow

1. **Data Ingestion**: User uploads CSV file through the main interface
2. **Data Validation**: System validates required columns and cleans data
3. **Session Storage**: Processed data is stored in Streamlit session state
4. **Search Operations**: Users can search by crop, disease, or symptoms with fuzzy matching
5. **AI Processing**: Chatbot queries are processed with relevant data context
6. **Visualization**: Analytics module generates insights and charts
7. **Export**: Results can be exported as CSV or PDF reports

## External Dependencies

### Core Libraries
- **streamlit**: Web application framework
- **pandas**: Data manipulation and analysis
- **openai**: AI chatbot functionality (requires API key)
- **fuzzywuzzy**: Fuzzy string matching for search
- **plotly**: Interactive data visualizations
- **reportlab**: PDF generation for reports

### API Requirements
- **OpenAI API Key**: Required for chatbot functionality (GPT-4o model)
- Environment variable: `OPENAI_API_KEY`

### Data Dependencies
- CSV dataset with specific column structure:
  - Crop Name
  - Disease Name
  - Symptoms
  - Cause
  - Organic Solution
  - Chemical Solution
  - Prevention Tips

## Deployment Strategy

### Environment Setup
- Python environment with required dependencies
- OpenAI API key configuration
- Streamlit server configuration

### Scalability Considerations
- Session-based data storage (suitable for individual user sessions)
- No persistent database required
- Stateless architecture allows for easy horizontal scaling

### Limitations
- Data is not persisted between sessions
- Requires API key for full functionality
- Performance depends on dataset size and OpenAI API response times

### Recommended Deployment
- Cloud platforms supporting Python/Streamlit (Streamlit Cloud, Heroku, etc.)
- Environment variable management for API keys
- Resource allocation based on expected concurrent users